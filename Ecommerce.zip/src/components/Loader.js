import styling from '../styles/Loader.module.css';

const Loader = () => {
    return(
        <div className={styling.loader__container}>
  <h1 className="loader__title">Loading...</h1>

        </div>
    )
}
export default Loader;